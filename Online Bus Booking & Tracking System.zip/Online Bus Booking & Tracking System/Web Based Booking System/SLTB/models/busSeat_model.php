<?php
class BusSeat_Model extends Model {

    public function __construct() {
        parent::__construct();
    }

    public function setSeatNo() {

        try {
            
        } catch (Exception $e){
            echo $e->getMessage();
        }
    }
    
    public function selectBusSeat() {

        try {
            
        } catch (Exception $e){
            echo $e->getMessage();
        }
    }
    
    public function deselectBusSeat() {

        try {
            
        } catch (Exception $e){
            echo $e->getMessage();
        }
    }
    
    public function serachBusSeat() {

        try {
            
        } catch (Exception $e){
            echo $e->getMessage();
        }
    }
    
}
?>
