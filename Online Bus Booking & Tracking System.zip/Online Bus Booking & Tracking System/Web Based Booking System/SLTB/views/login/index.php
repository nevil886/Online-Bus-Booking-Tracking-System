<h1>Login Page</h1>

<form action="<?php echo URL; ?>login/loginToSystem" method="post" id="log">
	
	<label>User Name</label><input type="text" name="userName" /><br />
	<label>Password</label><input type="password" name="password" /><br />
	<label></label><input type="submit" name="" id="" value="Login" />
</form>